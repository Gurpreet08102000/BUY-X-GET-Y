# Simple Buy X Get Y (WooCommerce)

**Promo**: Buy any _X_ items from **Category A** → auto-add **Product Y** free.  
Default X = 3 (configurable). Quantity guardrails included.

## Features
- Auto-add **Product Y** when the cart has enough items from Category A.
- Lock **Y** quantity to `floor(qualifying_count / X)`.
- Remove **Y** if rule no longer met.
- Force **Y** line price to **0** (free).
- **Progress notice** in cart & mini-cart: “Add 1 more to unlock your free gift.”
- **Admin settings page** (WooCommerce → Buy X Get Y):
  - Enable/disable rule
  - Choose Category A (product_cat)
  - Choose Product Y (ID)
  - Set threshold **X** (items required per gift)

## Requirements
- WordPress 6.0+
- WooCommerce 7.0+

## Installation
1. Download the ZIP and install as a plugin (Plugins → Add New → Upload Plugin).
2. Activate **Simple Buy X Get Y (WooCommerce)**.
3. Go to **WooCommerce → Buy X Get Y** and configure:
   - Enable promotion
   - Pick **Category A**
   - Enter **Product Y** (product or variation ID)
   - (Optional) change **X** (default 3)

## How it works
- The engine runs during cart load and total calculations.
- It counts **qualifying items** (from Category A), excludes the gift product itself.
- Computes `allowed_qty = floor(qualifying_count / X)`.
- Adds/removes/locks **Y** accordingly and sets its price to **0**.

## Guardrails
- Prevents manual purchase of **Y** when not eligible (blocks direct add-to-cart for Y).
- Locks **Y** quantity to allowed maximum.
- Removes **Y** when cart falls below requirement.

## Performance
- Single pass over cart contents.
- Uses `wc_get_product_term_ids()` for efficient category lookups.
- No heavy DB queries or session thrashing; avoids recursion with an internal running flag.

## Security & Best Practices
- Admin page requires `manage_woocommerce` capability.
- Options are sanitized on save.
- User-facing strings are internationalized (`__()`, `esc_html__()` etc.).
- Escaping applied where output is rendered in admin.

## Assumptions & Trade-offs
- **Product Y** must be purchasable. The plugin sets its cart price to `0` but does not alter catalog price.
- If **Y** is variable, specify a concrete **variation ID**.
- If your theme caches mini-cart output aggressively, clear caches after enabling the rule.
- We keep settings simple (no multiple rules, no exclusions). Extending to multiple rules would require a small rules array and iteration.

## Testing
1. Create a **product category** (e.g., "Category A") and note its **term ID**.
2. Create several test products assigned to that category.
3. Create a product to serve as **Product Y** (note its **product or variation ID**).
4. Configure plugin settings.
5. Add products from Category A to the cart:
   - At **1..(X-1)** items → see **progress notice**.
   - At **X** items → **Y** is added at price 0.
   - At **2X** items → **Y** qty becomes 2, etc.
   - Reduce quantity → **Y** qty reduces or is removed.

## Uninstall
Deactivate and delete the plugin. Options are kept (to preserve settings); delete `sbgy_settings` if you want a clean slate.

---

© Your Name. Licensed under GPL-2.0+.
